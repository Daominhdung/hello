package com.example.backendwebtienganh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendwebtienganhApplicationTests {

	@Test
	void contextLoads() {
	}

}
