package com.example.backendwebtienganh.dto;

public class Permission {
    private Long id;
    private String name;
    private String description;
    private String guardName;
    private String group;
    private String createdAt;
    private String updatedAt;

    public Permission() {
    }

    public Permission(Long id, String name, String description, String guardName, String group, String createdAt, String updatedAt) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.guardName = guardName;
        this.group = group;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getGuardName() {
        return guardName;
    }

    public void setGuardName(String guardName) {
        this.guardName = guardName;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    public void add(Permission permission) {
    }
}

