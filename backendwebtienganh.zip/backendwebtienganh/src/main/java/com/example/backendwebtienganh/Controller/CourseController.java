package com.example.backendwebtienganh.Controller;

import com.example.backendwebtienganh.dto.CourseRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/v1")
public class CourseController {
    @PostMapping("/course")
    public ResponseEntity<String> createCourse(@RequestBody CourseRequest courseRequest){
            return new ResponseEntity<>("Course created successfully", HttpStatus.CREATED);
        }
        private List<CourseRequest> course = new ArrayList<>();
    @PutMapping("course/{id}")
    public ResponseEntity<String> updateCourse(@PathVariable long id, @RequestBody CourseRequest courseRequest){
        Optional<CourseRequest> existingCourse = course.stream()
                .filter(course -> course.getId().equals(id))
                .findFirst();
        if(existingCourse.isPresent()){
            return new ResponseEntity<>("Course not found", HttpStatus.NOT_FOUND);
        }
        CourseRequest updateCourse = existingCourse.get();
        updateCourse.setName(courseRequest.getName());
        updateCourse.setCode(courseRequest.getCode());
        updateCourse.setContent(courseRequest.getContent());
        updateCourse.setStatus(courseRequest.getStatus());
        updateCourse.setClassIds(courseRequest.getClassIds());
        return new ResponseEntity<>("Course update successfully ", HttpStatus.OK);
    }
    @DeleteMapping("/courses/{id}")
    public ResponseEntity<String> deleteCourse(@PathVariable Long id){
        Optional<CourseRequest> existingCourse  = course.stream()
                .filter(course -> course.getId().equals(id))
                .findFirst();
        if(existingCourse.isPresent()){
            return new ResponseEntity<>("Course not found", HttpStatus.NOT_FOUND);
        }
        course.remove(existingCourse.get());
        return new ResponseEntity<>("Course deleted successfully", HttpStatus.OK);
    }

}
