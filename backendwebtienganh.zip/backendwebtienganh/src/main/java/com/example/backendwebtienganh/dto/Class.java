package com.example.backendwebtienganh.dto;

import java.time.LocalDateTime;

public class Class {
    private int id;
    private String name;
    private String code;
    private int studentMaxNumber;
    private int status;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    // Add getters and setters for each field
    // ...

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public int getStudentMaxNumber() {
        return studentMaxNumber;
    }

    public void setStudentMaxNumber(int studentMaxNumber) {
        this.studentMaxNumber = studentMaxNumber;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Override
    public String toString() {
        return "ClassesDTO{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", code='" + code + '\'' +
                ", studentMaxNumber=" + studentMaxNumber +
                ", status=" + status +
                ", createdAt=" + createdAt +
                ", updatedAt=" + updatedAt +
                '}';
    }
}

