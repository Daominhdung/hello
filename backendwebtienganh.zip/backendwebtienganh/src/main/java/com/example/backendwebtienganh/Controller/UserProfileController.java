package com.example.backendwebtienganh.Controller;

import com.example.backendwebtienganh.dto.UserProfileRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/auth")
public class UserProfileController {
    @PutMapping("/profiles")
    public ResponseEntity<String> updateProfile(@RequestBody UserProfileRequest userProfileRequest){
        return new ResponseEntity<>("Update profile successfull ", HttpStatus.OK);
    }
    @GetMapping("/profile")
    public ResponseEntity<UserProfileRequest> getUserProfile(){
        UserProfileRequest userProfile = new UserProfileRequest();
        userProfile.setFull_name("dung");
        userProfile.setAddress("hello");
        userProfile.setPhone("1234");
        return new ResponseEntity<>(userProfile, HttpStatus.OK);
    }
}
